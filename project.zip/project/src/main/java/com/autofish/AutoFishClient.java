package com.autofish;

import net.fabricmc.api.ClientModInitializer;

import java.awt.Robot;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.awt.event.InputEvent;

public class AutoFishClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        // اجرا در یک ترد مجزا برای جلوگیری از افت فریم بازی و عدم نیاز به کتابخانه‌های متغیر ماینکرفت
        Thread autoFishThread = new Thread(() -> {
            try {
                Robot robot = new Robot();
                Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
                Rectangle screenRect = new Rectangle(0, 0, screenSize.width, screenSize.height);

                while (true) {
                    // هر ۱۰۰ میلی‌ثانیه (۱۰ بار در ثانیه) کل صفحه اسکن می‌شود
                    Thread.sleep(100);

                    BufferedImage image = robot.createScreenCapture(screenRect);
                    boolean colorFound = false;

                    int width = image.getWidth();
                    int height = image.getHeight();

                    // اسکن با گام‌های ۵ پیکسلی برای سرعت فوق‌العاده بالا و بدون ایجاد لگ
                    for (int x = 0; x < width; x += 5) {
                        for (int y = 0; y < height; y += 5) {
                            int rgb = image.getRGB(x, y);
                            
                            // تفکیک کانال‌های رنگی (RGB)
                            int r = (rgb >> 16) & 0xFF;
                            int g = (rgb >> 8) & 0xFF;
                            int b = rgb & 0xFF;

                            // بررسی رنگ هدف: 0x4FC7FC (قرمز: 79، سبز: 199، آبی: 252) با تلورانس 40
                            if (Math.abs(r - 79) <= 40 && Math.abs(g - 199) <= 40 && Math.abs(b - 252) <= 40) {
                                colorFound = true;
                                break;
                            }
                        }
                        if (colorFound) break;
                    }

                    // در صورت مشاهده رنگ، کلیک راست انجام می‌شود
                    if (colorFound) {
                        robot.mousePress(InputEvent.BUTTON3_DOWN_MASK);
                        robot.mouseRelease(InputEvent.BUTTON3_DOWN_MASK);
                        
                        // وقفه ۳۰۰ میلی‌ثانیه‌ای پس از کلیک برای جلوگیری از کلیک‌های تکراری و متوالی
                        Thread.sleep(300);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        // بسته شدن خودکار ترد با بستن بازی
        autoFishThread.setDaemon(true);
        autoFishThread.start();
    }
}