package com.autofish;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

import java.awt.Robot;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.awt.Color;
import java.awt.event.InputEvent;

public class AutoFishClient implements ClientModInitializer {
    private Robot robot;
    private int ticker = 0;
    private Rectangle screenRect;

    @Override
    public void onInitializeClient() {
        try {
            robot = new Robot();
            // گرفتن خودکار سایز کل صفحه مانیتور
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            screenRect = new Rectangle(0, 0, screenSize.width, screenSize.height);
        } catch (Exception e) {
            e.printStackTrace();
        }

        ClientTickEvents.END_CLIENT_TICK.register((MinecraftClient client) -> {
            if (client.player == null || robot == null || screenRect == null) return;

            ticker++;
            // برای اینکه بازی لگ نگیرد، هر 5 تیک یک بار کل صفحه را اسکن می‌کند
            if (ticker >= 5) { 
                ticker = 0;
                
                // اسکن کامل تمام پیکسل‌های صفحه
                BufferedImage image = robot.createScreenCapture(screenRect);
                boolean colorFound = false;
                
                int width = image.getWidth();
                int height = image.getHeight();
                
                // برای سرعت بیشتر، هر 2 پیکسل در میان را اسکن می‌کند تا به فریم ریت بازی آسیبی نرسد
                for (int x = 0; x < width; x += 2) {
                    for (int y = 0; y < height; y += 2) {
                        Color c = new Color(image.getRGB(x, y));
                        
                        int r = c.getRed();
                        int g = c.getGreen();
                        int b = c.getBlue();
                        
                        // مقایسه رنگ هدف (0x4FC7FC) با تلورانس 40
                        if (Math.abs(r - 79) <= 40 && Math.abs(g - 199) <= 40 && Math.abs(b - 252) <= 40) {
                            colorFound = true;
                            break;
                        }
                    }
                    if (colorFound) break;
                }
                
                // اگر رنگ در هر جای صفحه پیدا شد
                if (colorFound) {
                    robot.mousePress(InputEvent.BUTTON3_DOWN_MASK);
                    robot.mouseRelease(InputEvent.BUTTON3_DOWN_MASK);
                }
            }
        });
    }
}